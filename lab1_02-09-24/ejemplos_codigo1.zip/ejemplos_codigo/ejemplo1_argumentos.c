/*
Para compilar: gcc -Wall code_baby.c -o babe.out
Para ejecutar: ./baby.out  
*/
// Librerias
#include <stdio.h>
#include <stdlib.h>

// Funcion main
int main() {
	int num_virgings = 7;
	/* Codigo... */
	printf("Learn to program in: www.codebabes.com ;)\n");
	printf("\nSubscribe: U$ 50/per month ;););)\n\n");
	printf("There are %d in all courses\n",num_virgings);
	return 0;
}